﻿namespace BkashSubscriptionApi.Services
{
    public interface IUniqueStringService
    {
        string GenerateUniqueString();
    }
}